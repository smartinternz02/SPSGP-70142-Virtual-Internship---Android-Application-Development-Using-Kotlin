# Virtual-Internship-Project-GroceryApp
---- SmartInternz Virtual Internship Program ----

GroceryApp Project

Submitted By : Yash Mahajan

SBID : SB20220205723

Email : yashmahajan270502@gmail.com

Demo Link : https://drive.google.com/file/d/1VAXJqxDZ3mrlUXxKlAxiPNFf6s5_YepK/view?usp=sharing
